package com.farlhmd.spring;



import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
 class SpringBootNgebusAjaApplicationTests {

	@Test
	 void contextLoads() {
	}

}
