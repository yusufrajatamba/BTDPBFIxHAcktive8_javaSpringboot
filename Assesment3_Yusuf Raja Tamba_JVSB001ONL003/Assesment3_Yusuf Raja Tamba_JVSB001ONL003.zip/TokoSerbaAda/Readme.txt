/*
Nama 		: Yusuf Raja Tamba
no Peserta 	: JVSB001ONL003
Link Github : https://github.com/yusufrajatamba/BTDPBFIxHAcktive8_javaSpringboot
Panduan Penggunaan :

 1. Nama Aplikasi : Aplikasi Aplikasi Toko Serba Ada
	..Kegunaan Aplikasi : Aplikasi ini adalah aplikasi API javaspringboot untuk menyimpan data product
	.. Penggunaan 	  : 1. Pada Menu Tampilan awal user akan disuguhkan untuk melakukan add product, update dan delete sebagai fungsi utama aplikasi
				    2. Add product berfungsi untuk menambahkan data baru
				    3. Update berfungsi untuk mengubah data 
				    4. Delete berfungsi untuk menghapus data product.
2. Aplikasi dapat run menggunakan eclipse dan digunakan melalui browser