public class ratarataclass extends CheckNilaiRatarata{

    
    static void rata(int a,int b, int c){
        float hasil = (a+b+c)/3;
        System.out.println(hasil);
}
    
}
