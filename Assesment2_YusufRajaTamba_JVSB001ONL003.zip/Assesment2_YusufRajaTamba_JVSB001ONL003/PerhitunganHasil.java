public class PerhitunganHasil extends JualBarang {

    static int mouseblutut(){

        double harga =149.999;
        double diskon = 0.1;

        


        return 0;

    }
    
}
