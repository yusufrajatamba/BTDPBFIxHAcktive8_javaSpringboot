//package AssignmentSesi3;

public class IncrementDecrement {

    public static void main(String[] args) {
        //Buat variabel awal

        int a =0;
        int b =0;
        int c =9;
        int d =9;

        //print ke -1

        System.out.println(" Print ke-1");
        System.out.println("A = " + a++); //hasil :0
        System.out.println("B = " + ++b);  //hasil :1
        System.out.println("C = " + c--);  //hasil : 9
        System.out.println("D = " + --d);  //hasil : 8
        

        //print ke-2 
        System.out.println(" Print ke-2");
        System.out.println("A = " + a++); //hasil :
        System.out.println("B = " + ++b);  //hasil :
        System.out.println("C = " + c--);  //hasil : 
        System.out.println("D = " + --d);  //hasil : 

        //print ke-3
        System.out.println(" Print ke-3");
        System.out.println("A = " + a++); //hasil :
        System.out.println("B = " + ++b);  //hasil :
        System.out.println("C = " + c--);  //hasil : 
        System.out.println("D = " + --d);  //hasil : 

            //print ke-4
        System.out.println(" Print ke-4");
        System.out.println("A = " + a++); //hasil :
        System.out.println("B = " + ++b);  //hasil :
        System.out.println("C = " + c--);  //hasil : 
        System.out.println("D = " + --d);  //hasil : 
   
    }


    
}
