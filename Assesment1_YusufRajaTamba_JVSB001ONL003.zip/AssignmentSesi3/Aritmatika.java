public class Aritmatika {
    public static void main(String[] args) {
        int a=12;
        int b=8;
        int c=5;

        int hasil = a+b-c;
        int hasi2 = a*b/c;
        int hasi3 = a+b*c;
        int hasi4 = a+b/c;
        int hasi5 = (a+b)*c;
        int hasi6 = (a-b)*c;


        System.out.println(hasil);
        System.out.println(hasi2);
        System.out.println(hasi3);
        System.out.println(hasi4);
        System.out.println(hasi5);
        System.out.println(hasi6);
    }
    
}
