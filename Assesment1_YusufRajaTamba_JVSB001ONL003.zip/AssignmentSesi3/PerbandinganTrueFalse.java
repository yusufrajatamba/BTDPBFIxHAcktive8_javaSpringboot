//package AssignmentSesi3;

public class PerbandinganTrueFalse {

    public static void main(String[] args) {
        int a =10;
        int b=8;
        int c=12;
        int d=5;

        System.out.println("Tes ke-1 = " + (a>b));
        System.out.println("Tes ke-2 = " + (b<a));
        System.out.println("Tes ke-3 = " + (c>=b));
        System.out.println("Tes ke-4 = " + (a>b));
        System.out.println("Tes ke-5 = " + (c==c));
        System.out.println("Tes ke-6 = " + (b!=d));
        System.out.println("Tes ke-7 = " + (d>b));
        System.out.println("Tes ke-8 = " + (c<=a));
        System.out.println("Tes ke-9 = " + (c==b));
        System.out.println("Tes ke-10 = " + (a%2!=c%2));
    }
    
}
